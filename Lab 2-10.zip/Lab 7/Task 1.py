#Fractional knapsack

def fractional_knapsack(items, capacity):

    if not items or capacity <= 0:
        return 0.0
    
    items.sort(key=lambda x: x[0]/x[1], reverse=True)
    
    value = 0.0
    for v, w in items:
        if capacity <= 0:
            break
        fraction = min(1, capacity/w)
        value += v * fraction
        capacity -= w * fraction
    
    return value

import unittest

class TestFractionalKnapsack(unittest.TestCase):
    def test_example_case(self):
        items = [(60, 10), (100, 20), (120, 30)]
        capacity = 50
        result = fractional_knapsack(items, capacity)
        self.assertAlmostEqual(result, 240.0)

    def test_empty_items(self):
        items = []
        capacity = 50
        result = fractional_knapsack(items, capacity)
        self.assertEqual(result, 0.0)

    def test_zero_capacity(self):
        items = [(60, 10), (100, 20), (120, 30)]
        capacity = 0
        result = fractional_knapsack(items, capacity)
        self.assertEqual(result, 0.0)

    def test_single_item_fits(self):
        items = [(100, 50)]
        capacity = 50
        result = fractional_knapsack(items, capacity)
        self.assertEqual(result, 100.0)

    def test_single_item_partial(self):
        items = [(100, 50)]
        capacity = 25
        result = fractional_knapsack(items, capacity)
        self.assertEqual(result, 50.0)

    def test_multiple_items_partial(self):
        items = [(40, 20), (100, 50), (60, 30)]
        capacity = 70
        result = fractional_knapsack(items, capacity)
        self.assertAlmostEqual(result, 140.0)

if __name__ == '__main__':
    unittest.main()