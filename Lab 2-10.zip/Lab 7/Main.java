class TaskScheduler {

    public int calculateLeastInterval(char[] tasks, int cooldown) {

        if (cooldown < 0) {
            throw new IllegalArgumentException("Cooldown time must be a non-negative integer.");
        }

        int[] taskCounts = new int[26];

        for (char task : tasks) {
            taskCounts[task - 'A']++;
        }

        int maxFrequency = taskCounts[0];
        for (int count : taskCounts) {
            if (count > maxFrequency) {
                maxFrequency = count;
            }
        }

        int maxFrequencyCount = 0;
        for (int count : taskCounts) {
            if (count == maxFrequency) {
                maxFrequencyCount++;
            }
        }

        int intervals = (maxFrequency - 1) * (cooldown + 1) + maxFrequencyCount;
        return Math.max(intervals, tasks.length);
    }
}

public class Main {
    public static void main(String[] args) {
        TaskScheduler scheduler = new TaskScheduler();

        try {
            char[] tasks1 = {'A', 'A', 'A', 'B', 'B', 'B'};
            int cooldown1 = 0;
            System.out.println("Test Case 1 Result: " + scheduler.calculateLeastInterval(tasks1, cooldown1));
            System.out.println("Test Case 1 Expected: 6");

            char[] tasks2 = {'A', 'A', 'A', 'B', 'B', 'B'};
            int cooldown2 = 2;
            System.out.println("Test Case 2 Result: " + scheduler.calculateLeastInterval(tasks2, cooldown2));
            System.out.println("Test Case 2 Expected: 8");
            // A B _ A B _ A B
            char[] tasks3 = {'A', 'A', 'A', 'A'};
            int cooldown3 = 3;
            System.out.println("Test Case 3 Result: " + scheduler.calculateLeastInterval(tasks3, cooldown3));
            System.out.println("Test Case 3 Expected: 13");

            char[] tasks4 = {'A', 'B', 'C', 'A', 'B', 'C'};
            int cooldown4 = 2;
            System.out.println("Test Case 4 Result: " + scheduler.calculateLeastInterval(tasks4, cooldown4));
            System.out.println("Test Case 4 Expected: 6");

            char[] tasks5 = {'A'};
            int cooldown5 = 0;
            System.out.println("Test Case 5 Result: " + scheduler.calculateLeastInterval(tasks5, cooldown5));
            System.out.println("Test Case 5 Expected: 1");

            char[] tasks6 = {'A', 'A', 'A', 'B', 'B', 'B'};
            int cooldown6 = -1;
            System.out.println("Test Case 6 Result: " + scheduler.calculateLeastInterval(tasks6, cooldown6));

        } catch (IllegalArgumentException e) {
            System.out.println("Exception caught: " + e.getMessage());
        }
    }
}
