import unittest

def insertion_sort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key
    return arr

class TestInsertionSort(unittest.TestCase):
    def test_sorting(self):
        filename = r'C:\Users\ganbo\Desktop\algorithm\Lab 2\lists.txt'
        with open(filename, 'r') as file:
            for line in file:
                unsorted, expected = map(eval, line.strip().split('\t'))
                with self.subTest(unsorted=unsorted):
                    sorted_list = insertion_sort(unsorted)
                    self.assertEqual(sorted_list, expected)
                    unsorted = eval(line.strip().split('\t')[0])

if __name__ == '__main__':
    unittest.main()