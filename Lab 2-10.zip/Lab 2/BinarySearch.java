import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class BinarySearch {
    public static int binarySearch(int[] arr, int target, int low, int high, int depth) {

        if (low > high) {
            return -1;
        }

        int mid = (low + high) / 2;

        if (arr[mid] == target) {
            return mid;
        } else if (arr[mid] > target) {
            return binarySearch(arr, target, low, mid - 1, depth + 1);
        } else {
            return binarySearch(arr, target, mid + 1, high, depth + 1);
        }
    }

    public static void main(String[] args) {
        String filename = "C:\\Users\\ganbo\\Desktop\\algorithm\\Lab 2\\listsBinary.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\t");
                int[] sortedList = parseIntArray(parts[0]);
                int[] targets = parseIntArray(parts[1]);
                
                for (int target : targets) {
                    System.out.println("\nSearching for " + target + " in " + Arrays.toString(sortedList));
                    int result = binarySearch(sortedList, target, 0, sortedList.length - 1, 0);
                    if (result != -1) {
                        System.out.println("Found " + target + " at index " + result);
                    } else {
                        System.out.println(target + " not found in the list");
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static int[] parseIntArray(String s) {
        s = s.substring(1, s.length() - 1);
        String[] parts = s.split(",");
        int[] result = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            result[i] = Integer.parseInt(parts[i].trim());
        }
        return result;
    }
}