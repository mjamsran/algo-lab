import unittest
import ast

def binary_search(arr, target, low=0, high=None, depth=0):
    if high is None:
        high = len(arr) - 1

    print("  " * depth + f"Searching in {arr[low:high+1]} for {target}")

    if low > high:
        print("  " * depth + "Element not found")
        return -1

    mid = (low + high) // 2
    print("  " * depth + f"Comparing with middle element {arr[mid]}")

    if arr[mid] == target:
        print("  " * depth + f"Found {target} at index {mid}")
        return mid
    elif arr[mid] > target:
        print("  " * depth + "Target is in the left half")
        return binary_search(arr, target, low, mid - 1, depth + 1)
    else:
        print("  " * depth + "Target is in the right half")
        return binary_search(arr, target, mid + 1, high, depth + 1)

class TestBinarySearch(unittest.TestCase):
    def test_searching(self):
        filename = r'C:\Users\ganbo\Desktop\algorithm\Lab 2\listsBinary.txt'
        with open(filename, 'r') as file:
            for line in file:
                sorted_list, targets = map(ast.literal_eval, line.strip().split('\t'))
                for target in targets:
                    with self.subTest(sorted_list=sorted_list, target=target):
                        print(f"\nSearching for {target} in {sorted_list}")
                        result = binary_search(sorted_list, target)
                        if result != -1:
                            self.assertEqual(sorted_list[result], target)
                        else:
                            self.assertNotIn(target, sorted_list)

if __name__ == '__main__':
    unittest.main()