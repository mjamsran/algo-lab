import unittest
import ast

def find_max(arr, low=0, high=None, depth=0):
    if high is None:
        high = len(arr) - 1

    print("  " * depth + f"Finding max in {arr[low:high+1]}")

    if low == high:
        print("  " * depth + f"Base case reached, max is {arr[low]}")
        return arr[low]

    mid = (low + high) // 2
    print("  " * depth + f"Splitting at index {mid}")

    max_left = find_max(arr, low, mid, depth + 1)
    max_right = find_max(arr, mid + 1, high, depth + 1)

    overall_max = max(max_left, max_right)
    print("  " * depth + f"Max between {max_left} and {max_right} is {overall_max}")
    return overall_max

class TestFindMax(unittest.TestCase):
    def test_finding_max(self):
        filename = r'C:\Users\ganbo\Desktop\algorithm\Lab 2\listsBinary.txt'
        with open(filename, 'r') as file:
            for line in file:
                sorted_list, _ = map(ast.literal_eval, line.strip().split('\t'))
                with self.subTest(sorted_list=sorted_list):
                    print(f"\nFinding max in {sorted_list}")
                    result = find_max(sorted_list)
                    self.assertEqual(result, max(sorted_list))

if __name__ == '__main__':
    unittest.main()
