import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class FindMax {
    public static int findMax(int[] arr, int low, int high) {
        if (low == high) {
            return arr[low];
        }

        int mid = (low + high) / 2;

        int maxLeft = findMax(arr, low, mid);
        int maxRight = findMax(arr, mid + 1, high);

        return Math.max(maxLeft, maxRight);
    }

    public static void main(String[] args) {
        String filename = "C:\\Users\\ganbo\\Desktop\\algorithm\\Lab 2\\listsBinary.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\t");
                int[] sortedList = parseIntArray(parts[0]);
                
                System.out.println("\nFinding max in " + Arrays.toString(sortedList));
                int result = findMax(sortedList, 0, sortedList.length - 1);
                System.out.println("Max value: " + result);
                System.out.println("Correct:   " + (result == Arrays.stream(sortedList).max().getAsInt()));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static int[] parseIntArray(String s) {
        s = s.substring(1, s.length() - 1);
        String[] parts = s.split(",");
        int[] result = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            result[i] = Integer.parseInt(parts[i].trim());
        }
        return result;
    }
}