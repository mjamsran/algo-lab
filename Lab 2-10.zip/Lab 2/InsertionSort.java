import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class InsertionSort {
    public static int[] insertionSort(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
        return arr;
    }

    public static void main(String[] args) {
        String filename = "C:\\Users\\ganbo\\Desktop\\algorithm\\Lab 2\\lists.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\t");
                int[] unsorted = parseIntArray(parts[0]);
                int[] expected = parseIntArray(parts[1]);
                
                System.out.println("Unsorted: " + Arrays.toString(unsorted));
                int[] sorted = insertionSort(unsorted.clone());
                System.out.println("Sorted:   " + Arrays.toString(sorted));
                System.out.println("Expected: " + Arrays.toString(expected));
                System.out.println("Correct:  " + Arrays.equals(sorted, expected));
                System.out.println();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static int[] parseIntArray(String s) {
        s = s.substring(1, s.length() - 1);
        String[] parts = s.split(",");
        int[] result = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            result[i] = Integer.parseInt(parts[i].trim());
        }
        return result;
    }
}