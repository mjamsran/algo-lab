from functools import lru_cache
from typing import List

class StairClimber:
    def __init__(self):
        self.memo = {}

    def climb_stairs_recursive(self, n: int) -> int:
        """
        Recursive solution with memoization.
        Time complexity: O(n)
        Space complexity: O(n)
        """
        @lru_cache(maxsize=None)
        def climb(i: int) -> int:
            if i <= 1:
                return 1
            return climb(i - 1) + climb(i - 2)
        
        return climb(n)

    def climb_stairs_iterative(self, n: int) -> int:
        """
        Iterative solution with constant space.
        Time complexity: O(n)
        Space complexity: O(1)
        """
        if n <= 1:
            return 1
        
        prev, curr = 1, 1
        for _ in range(2, n + 1):
            prev, curr = curr, prev + curr
        
        return curr

    def climb_stairs_matrix(self, n: int) -> int:
        """
        Matrix exponentiation solution.
        Time complexity: O(log n)
        Space complexity: O(1)
        """
        def matrix_multiply(a: List[List[int]], b: List[List[int]]) -> List[List[int]]:
            return [
                [a[0][0] * b[0][0] + a[0][1] * b[1][0], a[0][0] * b[0][1] + a[0][1] * b[1][1]],
                [a[1][0] * b[0][0] + a[1][1] * b[1][0], a[1][0] * b[0][1] + a[1][1] * b[1][1]]
            ]

        def matrix_power(matrix: List[List[int]], power: int) -> List[List[int]]:
            result = [[1, 0], [0, 1]]  # Identity matrix
            while power > 0:
                if power % 2 == 1:
                    result = matrix_multiply(result, matrix)
                matrix = matrix_multiply(matrix, matrix)
                power //= 2
            return result

        if n <= 1:
            return 1

        base_matrix = [[1, 1], [1, 0]]
        result_matrix = matrix_power(base_matrix, n - 1)
        return result_matrix[0][0]

# Usage example
climber = StairClimber()
n = 45
print(f"Recursive: {climber.climb_stairs_recursive(n)}")
print(f"Iterative: {climber.climb_stairs_iterative(n)}")
print(f"Matrix: {climber.climb_stairs_matrix(n)}")