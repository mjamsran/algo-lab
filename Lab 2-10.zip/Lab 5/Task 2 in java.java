import java.util.Arrays;

public class Knapsack {
    public static int knapsack(int W, int[] weights, int[] values, int n) {
        int[][] dp = new int[n + 1][W + 1];

        for (int i = 0; i <= n; i++) {
            for (int w = 0; w <= W; w++) {
                if (i == 0 || w == 0)
                    dp[i][w] = 0;
                else if (weights[i - 1] <= w)
                    dp[i][w] = Math.max(values[i - 1] + dp[i - 1][w - weights[i - 1]], dp[i - 1][w]);
                else
                    dp[i][w] = dp[i - 1][w];
            }
        }

        return dp[n][W];
    }
    public static void main(String[] args) {
        int[] values = {60, 100, 120};
        int[] weights = {10, 20, 30};
        int W = 50;
        int n = values.length;

        int result = knapsack(W, weights, values, n);
        System.out.println("Maximum value: " + result);

        assert knapsack(50, new int[]{10, 20, 30}, new int[]{60, 100, 120}, 3) == 220 : "Test case 1 failed";
        assert knapsack(10, new int[]{5, 4, 6, 3}, new int[]{10, 40, 30, 50}, 4) == 90 : "Test case 2 failed";
        assert knapsack(0, new int[]{1, 2, 3}, new int[]{10, 20, 30}, 3) == 0 : "Test case 3 failed";

        System.out.println("All test cases passed!");
    }
}