import unittest

def fibonacci(n):
    if n < 0:
        raise ValueError("n must be a non-negative integer")
    
    def fib_memo(n, memo):
        if n in memo:
            return memo[n]
        if n <= 1:
            return n
        memo[n] = fib_memo(n - 1, memo) + fib_memo(n - 2, memo)
        return memo[n]
    
    return fib_memo(n, {})

class TestFibonacci(unittest.TestCase):
    def test_fibonacci(self):
        self.assertEqual(fibonacci(0), 0)
        self.assertEqual(fibonacci(1), 1)
        self.assertEqual(fibonacci(2), 1)
        self.assertEqual(fibonacci(5), 5)
        self.assertEqual(fibonacci(10), 55)
        self.assertEqual(fibonacci(20), 6765)
    
    def test_fibonacci_large_number(self):
        self.assertEqual(fibonacci(50), 12586269025)
    
    def test_fibonacci_negative_number(self):
        with self.assertRaises(ValueError):
            fibonacci(-1)

if __name__ == '__main__':
    unittest.main()