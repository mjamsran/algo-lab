# File: test_num_trees.py
import unittest
from num_trees import Solution

class TestNumTrees(unittest.TestCase):
    def setUp(self):
        self.solution = Solution()

    def test_num_trees(self):
        self.assertEqual(self.solution.numTrees(3), 5)
        self.assertEqual(self.solution.numTrees(1), 1)
        
        # Additional test cases
        self.assertEqual(self.solution.numTrees(0), 1)
        self.assertEqual(self.solution.numTrees(2), 2)
        self.assertEqual(self.solution.numTrees(4), 14)
        self.assertEqual(self.solution.numTrees(5), 42)

    def test_large_input(self):
        self.assertEqual(self.solution.numTrees(10), 16796)

    def test_edge_cases(self):
        self.assertEqual(self.solution.numTrees(0), 1)
        self.assertEqual(self.solution.numTrees(1), 1)

    def test_performance(self):
        import time
        start_time = time.time()
        self.solution.numTrees(19)  # A larger input to test performance
        end_time = time.time()
        self.assertLess(end_time - start_time, 1)  # Should complete in less than 1 second

if __name__ == '__main__':
    unittest.main()