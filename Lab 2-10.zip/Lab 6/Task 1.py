import unittest

class Solution:
    def numTrees(self, n: int) -> int:
        if n <= 1:
            return 1
        
        dp = [0] * (n + 1)
        
        dp[0] = 1
        
        for nodes in range(1, n + 1):
            for root in range(1, nodes + 1):

                left_trees = dp[root - 1]
                right_trees = dp[nodes - root]
                dp[nodes] += left_trees * right_trees
                
        
        return dp[n]

class TestUniqueBST(unittest.TestCase):
    def setUp(self):
        self.solution = Solution()
    
    def test_base_cases(self):
        self.assertEqual(self.solution.numTrees(0), 1)
        self.assertEqual(self.solution.numTrees(1), 1)
    
    def test_small_inputs(self):
        self.assertEqual(self.solution.numTrees(2), 2)
        self.assertEqual(self.solution.numTrees(3), 5)
        self.assertEqual(self.solution.numTrees(4), 14)
    
    def test_larger_input(self):
        self.assertEqual(self.solution.numTrees(5), 42)
        
    def test_type_error(self):
        with self.assertRaises(TypeError):
            self.solution.numTrees("3")
        with self.assertRaises(TypeError):
            self.solution.numTrees(3.5)

if __name__ == '__main__':
    unittest.main()