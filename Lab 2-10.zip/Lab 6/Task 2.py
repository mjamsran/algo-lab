def optimal_bst(keys, freq):
    n = len(keys)
    dp = [[0] * n for _ in range(n)]
    
    for i in range(n):
        dp[i][i] = freq[i]
    
    for length in range(2, n + 1):  
        for i in range(n - length + 1):
            j = i + length - 1
            dp[i][j] = float('inf')
            freq_sum = sum(freq[i:j+1])
            
            for r in range(i, j + 1):
                left = dp[i][r-1] if r > i else 0
                right = dp[r+1][j] if r < j else 0
                cost = left + right + freq_sum
                dp[i][j] = min(dp[i][j], cost)
    
    return dp[0][n-1]

if __name__ == "__main__":
    keys = [5, 6]
    freq = [17, 25]
    print(optimal_bst(keys, freq))

import unittest

class TestOptimalBST(unittest.TestCase):
    def test_optimal_bst(self):
        keys1 = [5, 6]
        freq1 = [17, 25]
        self.assertEqual(optimal_bst(keys1, freq1), 59)
        
        keys2 = [10, 12, 20]
        freq2 = [34, 8, 50]
        self.assertEqual(optimal_bst(keys2, freq2), 142)
        
        keys3 = [10, 12, 16, 21]
        freq3 = [4, 2, 6, 3]
        self.assertEqual(optimal_bst(keys3, freq3), 26)
        
        # Edge case: single node
        keys4 = [5]
        freq4 = [10]
        self.assertEqual(optimal_bst(keys4, freq4), 10)

if __name__ == '__main__':
    unittest.main()